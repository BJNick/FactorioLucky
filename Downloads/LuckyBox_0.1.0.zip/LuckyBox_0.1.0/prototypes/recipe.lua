data:extend(
{
  {
    type = "recipe",
    name = "lucky-box",
    energy_required = 2,
    ingredients =
	{
	  {"wooden-chest", 1},
	  {"iron-gear-wheel", 3},
	  {"electronic-circuit", 5},
	  {"grenade", 2},
	},
	result = "lucky-box"
  },
}
)