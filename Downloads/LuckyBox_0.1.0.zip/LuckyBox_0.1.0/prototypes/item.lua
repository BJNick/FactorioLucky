data:extend(
{
  {
    type = "item",
    name = "lucky-box",
    icon = "__LuckyBox__/graphics/icons/lucky-box-1.png",
    icon_size = 32,
    flags = {"goes-to-quickbar"},
    subgroup = "storage",
    order = "b[lucky]-b[2]",
    place_result = "lucky-box",
    stack_size = 50
  },
}
)